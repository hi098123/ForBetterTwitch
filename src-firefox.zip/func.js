document.getElementById("intro").addEventListener('click', function(event){
	browser.tabs.create({url: 'https://hi098123.github.io/TwitchServerChecker/', active: true});
});

document.getElementById("update").addEventListener('click', function(event){
	browser.tabs.create({url: 'https://browser.google.com/webstore/detail/bohhpcaljnggabklkeanncbebknjpcod', active: true});
});

browser.runtime.onUpdateAvailable.addListener(()=>{
	document.getElementById("update").style.display="block";
});

function LocChange(country_,city_){
	document.getElementById('before').style.display="none";
	document.getElementById('after').style.display="block";
	document.getElementById('locate_server').innerText=""+country_+", "+city_;
	Timeout_loc=31;
	clearInterval(play);
}

var loccode;
var Timeout_loc=0;
var querying = browser.tabs.query({active: true});
querying.then((tab)=>{
	var url = new URL(tab[0].url);
	if(url.hostname=="www.twitch.tv"){
		var xhr = new XMLHttpRequest();
		xhr.open("GET" , browser.extension.getURL("data/loc.json") , true);
		xhr.onreadystatechange = function() {
		    if(xhr.readyState == 4 && xhr.status == 200)
		    {
		    	var jsonobj=JSON.parse(xhr.responseText);
		    	play = setInterval(function() {
		    		Timeout_loc++;
		    		if(Timeout_loc>30){
		    			if(Timeout_loc==31){
							document.getElementById('before').style.display="none";
							document.getElementById('after').style.display="block";
				    		document.getElementById('locate_server').innerText="Unknown";
		    			}else{
		    				console.log("ERR : 0000");
			    			clearInterval(play);
		    				return false;
		    			}
		    		}else if(typeof(loccode)!='undefined'){
		    			if(loccode=="AM"){
							document.getElementById('before').style.display="none";
							document.getElementById('after').style.display="block";
				    		document.getElementById('locate_server').innerText="Slow Server";
				    		Timeout_loc=31;
				    	}else if(jsonobj.hasOwnProperty(loccode.toUpperCase())){
				    		LocChange(jsonobj[loccode.toUpperCase()].country,jsonobj[loccode.toUpperCase()].city);
				    	}
		    		}
				}, 100);    	
		    }
		}
		xhr.send();
	}else{
		document.getElementById('locate_server').innerText="Not Twitch"
	}
}, ()=>{});

function ToggleBtn(num){
	var obj=document.getElementById("btn"+num);
	if(obj.className=='xi-toggle-off'){
		obj.className='xi-toggle-on';
		return true;
	}else{
		obj.className='xi-toggle-off';
		return false;
	}
}