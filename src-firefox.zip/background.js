browser.runtime.onInstalled.addListener(function(){
	browser.tabs.create({url: 'https://hi098123.github.io/TwitchServerChecker/', active: true});
});
browser.runtime.onStartup.addListener(function() {
    UpdateServerCheck();
})

function UpdateServerCheck(){
	if (browser.webRequest.onResponseStarted.hasListener(CheckStreamServer)) {
		browser.webRequest.onResponseStarted.removeListener(CheckStreamServer);
	}
	browser.webRequest.onResponseStarted.addListener(
		CheckStreamServer, 
		{urls: ['*://*.ttvnw.net/*','*://*.akamaized.net/*']}
	);
}
UpdateServerCheck();

browser.webNavigation.onCompleted.removeListener(LoadSet);
browser.webNavigation.onCompleted.addListener(LoadSet, {url: [{hostContains:'twitch.tv'}]});


var load =true;
var akamaized_not=true;
function CheckStreamServer(detail){
	if(akamaized_not){
		browser.browserAction.setIcon({path:"twitchlogo.png"});
	}else{
    	browser.browserAction.setIcon({path:"twitchTT.png"});
	}
	if (detail.method=="POST") {return true;}
	if(typeof(detail.url)!='undefined'){
		var urls = new URL(detail.url);
		if(!urls.hostname.indexOf("video-weaver")){return true;}
		loccode=urls.hostname.split(".")[1].split("0")[0];

	    if(loccode=="akamaized"){
	    	browser.browserAction.setIcon({path:"twitchTT.png"});
	    	akamaized_not=false;
	    	loccode="AM";
	    }else if(load){
	    	load=false;
	    }
	}
}

function LoadSet(){
	browser.browserAction.setIcon({path:"twitchlogo.png"});
	browser.tabs.executeScript(null, {
		code:
		"console.log('TwitchServerChecker : Status Ok')"
	}, null);
}
LoadSet();