chrome.runtime.onInstalled.addListener(function(){
	chrome.tabs.create({url: 'https://hi098123.github.io/TwitchServerChecker/', active: true});
	UpdateServerCheck();
	LoadLis();
});

function UpdateServerCheck(){
	if (chrome.webRequest.onResponseStarted.hasListener(CheckStreamServer)) {
		chrome.webRequest.onResponseStarted.removeListener(CheckStreamServer);
	}
	chrome.webRequest.onResponseStarted.addListener(
		CheckStreamServer, 
		{urls: ['*://*.ttvnw.net/*','*://*.akamaized.net/*']}
	);
}
UpdateServerCheck();

function LoadLis(){
	if (chrome.webNavigation.onCompleted.hasListener(LoadSet)) {
		chrome.webNavigation.onCompleted.removeListener(LoadSet);
	}
	chrome.webNavigation.onCompleted.addListener(LoadSet, {urls: ['*://*.twitch.tv/*']});
}
LoadLis();

var load =true;
var akamaized_not=true;
function CheckStreamServer(detail){
	if (detail.method=="POST") {return true;}
	if(typeof(detail.url)!='undefined'){
		var urls = new URL(detail.url);
		if(!urls.hostname.indexOf("video-weaver")){return true;}
		loccode=urls.hostname.split(".")[1].split("0")[0];

	    if(loccode=="akamaized"){
			chrome.browserAction.setBadgeText({text: "S"});
	    	akamaized_not=false;
	    	loccode="AM";
	    }else if(load){
	    	load=false;
	    }
	}
}

function LoadSet(){
	chrome.browserAction.setBadgeBackgroundColor({ color: [255, 0, 0, 255] });
	chrome.browserAction.setBadgeText({text: ""});
	chrome.tabs.executeScript(null, {
		code:
		"console.log('TwitchServerChecker : Status Ok')"
	}, null);
}
LoadSet();